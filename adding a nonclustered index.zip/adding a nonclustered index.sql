CREATE NONCLUSTERED INDEX IN_WaiterSurname
ON Waiter(WaiterSurname)